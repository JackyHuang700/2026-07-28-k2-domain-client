import React, { useState } from "react";
import DomainBuy from "./components/DomainBuy";
import Login from "./components/Login";
import MyDomains from "./components/MyDomains";
import MyOrders from "./components/MyOrders";
import MyWallet from "./components/MyWallet";

function App() {
  // 1. 新增：判斷使用者是否已登入 (預設為 false)
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // 2. 登入後預設顯示的頁面
  const [currentPage, setCurrentPage] = useState("wallet");

  // 3. 處理登出的功能 (將狀態改回未登入)
  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage("wallet"); // 重置預設頁面
  };

  // 如果尚未登入，只渲染登入頁面，並將 setIsAuthenticated 傳給它
  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  // 如果已經登入，就渲染主控台畫面 (我們把 handleLogout 傳給元件，讓左下角按鈕可以登出)
  return (
    <div className="min-h-screen bg-[#F7F5F0]">
      {currentPage === "purchase" && (
        <DomainBuy setCurrentPage={setCurrentPage} onLogout={handleLogout} />
      )}
      {currentPage === "my-domains" && (
        <MyDomains setCurrentPage={setCurrentPage} onLogout={handleLogout} />
      )}
      {currentPage === "wallet" && (
        <MyWallet setCurrentPage={setCurrentPage} onLogout={handleLogout} />
      )}
      {currentPage === "order" && (
        <MyOrders setCurrentPage={setCurrentPage} onLogout={handleLogout} />
      )}
    </div>
  );
}

export default App;
